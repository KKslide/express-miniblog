/**
 * Created by Administrator on 2017/10/26.
 */
var mongoose = require("mongoose");

module.exports = new mongoose.Schema({
    name: String
});